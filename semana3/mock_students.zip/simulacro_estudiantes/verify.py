#Colors
DANGER = "\033[91m"
WARNING = "\033[93m"
SUCCESS = "\033[92m"
RESET = "\033[0m"

def verify_positive(number,type_of):
    """Function that verifies that a number is, in fact, positive.

    Args:
        number (int or float): The number that will be checked.
        type_of (str): The type of number (\"int\" or \"float\")
    
    Returns:
        number (int or float): The number after being checked
    """

    if number >= 0:
        return number
    else:
        print(DANGER + "Error, el numero es negativo" + RESET)
        number = input("Ingrese un numero valido: ")

        if type_of == "integer":
            number = verify_int(number)
        
        else:

            number = verify_float(number)


def verify_float(number):
    """Function that verifies that a number is, in fact, float.

    Args:
        number (str): The string that will be casted to float

    Returns:
        number (float): The number after being casted to float
    """


    while 1:

        try:

            number = float(number)
            return number

        except ValueError:

            print(DANGER + "Error, el numero no es valido." + RESET)
            number = input("Ingrese un numero valido decimal o entero: ")

def verify_int(number):
    """Function that verifies that a given number is, in fact, an integer.

    Args:
        number (str): The string that will be casted to integer

    Returns:
        number (int): The number after being casted to integer
    """

    while 1:

        if number.isdigit():
            return int(number)
        else:
            print(DANGER + "Error, el numero no es valido." + RESET)
            number = input("Ingrese un numero entero valido: ")

def verify_range(start,finish,number,type_of):
    """Function that verifies that a given number is between a given range.

    Args:
        start (int or float): The start number
        finish (int or float): The finish number
        number (int or float): The number that will be checked
        type_of (str): The type of number (\"int\" or \"float\")

    Returns:
        number (int or float): The number after being checked 
    """


    while 1:
        if number >= start and number <= finish:
            return number
        else:
            print(DANGER + "Error, el numero esta fuera de rango" + RESET)
            number = input(f"Por favor ingrese un numero desde {start} hasta {finish}: ")

            if type_of == "integer":

                number = verify_int(number)
            else:
                number = verify_float(number)

def verify_min_students(students):
    """Function that verifies that there is at least one student in the students' dictionary

    Args:
        students (dict): Dictionary of students
    
    Returns:
        (bool): False if there is at least one student, otherwise True
    """

    if len(students) == 0:
        print(WARNING + "No hay estudiantes registrados" + RESET)
        return True
    else:
        return False
