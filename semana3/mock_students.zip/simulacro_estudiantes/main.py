#Module that has all the functions needed to verify data types and collections
from verify import *


#Colors
DANGER = "\033[91m"
WARNING = "\033[93m"
SUCCESS = "\033[92m"
RESET = "\033[0m"

#Dictionary of students
students = {
    0:{
        "name":"Johan",
        "age":20,
        "grade":4.0
    },
    1:{
        "name":"Kevin",
        "age":18,
        "grade":2.3
    },
    2:{
        "name":"Duran",
        "age":21,
        "grade":4.9
    },
    3:{
        "name":"Carlos",
        "age":33,
        "grade":3.9
    },
    4:{
        "name":"Brayan",
        "age":25,
        "grade":1.2
    }

}

#Function main
def main():

    print("1.Agregar estudiantes")
    print("2.Buscar un estudiante")
    print("3.Actualizar la informacion de un estudiante")
    print("4.Eliminar estudiante")
    print("5.Calcular el promedio de notas")
    print("6.Listar a los estudiantes dado un umbral")
    print("7.Salir")

    option = input("Seleccione una opcion del 1 al 7: ")

    option = verify_int(option)

    option = verify_range(1,7,option,"integer")

    if option == 1:
        option_1_add_student()
    elif option == 2:
        option_2_search_for_student()
    elif option == 3:
        option_3_uptade_student_info()
    elif option == 4:
        option_4_delete_student()
    elif option == 5:
        option_5_calculate_mean_grades()
    elif option == 6:
        option_6_list_students()
    else:
        print("Saliendo...")

#Function #1
def option_1_add_student():
    """Function that adds an student provided that there is at least one student in the students' dictionary
    """

    if verify_min_students(students):

        pass
    else:

        id = input("Ingrese el id del estudiante: ")

        id = verify_int(id)
        id = verify_positive(id,"integer")

        if id in students.keys():
            print(WARNING + f"El estudiante con id #{id} ya existe" + RESET)

        else:


            name = input("Ingresa el nombre del estudiante: ")


            age = input("Ingresa la edad del estudiante: ")

            age = verify_int(age)
            age = verify_positive(age,"integer")

            grade = input("Ingrese la calificacion del 0 al 5: ")

            grade = verify_float(grade)
            grade = verify_range(0,5,grade,"float")

            #Adding the student to the students' dictionary
            students[id] = {
                "name":name,
                "age":age,
                "grade":grade
            }

            #Output
            print(SUCCESS + f"Se ha agregado al estudiante con id #{id} exitosamente" + RESET)

    main()

def option_2_search_for_student():
    """Function that searchs for a student provided that there is at least one student in the students' 
    dictionary
    """

    if verify_min_students(students):
        pass
    else:

        print("Desea buscar por: ")
        print("1.ID")
        print("2.Nombre")
        option = input("Seleccione una opcion: ")

        option = verify_int(option)
        option = verify_range(1,2,option,"integer")

        if option == 1:

            id = input("Ingrese el id del estudiante que desea buscar: ")

            id = verify_int(id)
            id = verify_positive(id,"integer")

            if id not in students.keys():

                print(WARNING + f"El estudiante con id #{id} no se encuentra registrado" + RESET)

            else:
                
                #Output
                print(SUCCESS + "=====================" + RESET)
                print("====================")
                print(f"Id: {id}")
                print(f"Nombre: {students[id]["name"]}")
                print(f"Edad: {students[id]["age"]}")
                print(f"Nota: {students[id]["grade"]}")
                print("====================")
                print(SUCCESS + "=====================" + RESET)

        else:

            name = input("Ingrese el nombre del estudiante que desea buscar: ")

            #Boolean for storing if the student with the given name exists
            found = False

            #Variable where will be stored the student provided that the name of the student exists
            selected = 0

            for h in students.items():

                if h[1]["name"] == name:
                    found = True
                    selected = h
                    break
            
            else:
                #Output
                print(WARNING + f"No hay un estudiante registrado como {name}" + RESET)

            if found:

                print(SUCCESS + "=====================" + RESET)
                print("=====================")
                print(f"Id: {selected[0]}")
                print(f"Nombre: {name}")
                print(f"Edad: {selected[1]["age"]}")
                print(f"Nota: {selected[1]["grade"]}")
                print("=====================")
                print(SUCCESS + "=====================" + RESET)

    main()
            
def option_3_uptade_student_info():
    """Function that updates a student information provided that there is at least one 
    student in the students' dictionary
    """
    if verify_min_students(students):
        pass
    else:

        id = input("Ingrese el id del estudiante que desea actualizar: ")
        id = verify_int(id)
        id = verify_positive(id,"integer")

        if id not in students.keys():

            #Output
            print(WARNING + f"El estudiante con id #{id} no se encuentra registrado" + RESET)

        else:

            print("Desea actualizar:")
            print("1.Edad")
            print("2.Nota")
            print("3.Ambas")

            option = input("Seleccione una opcion: ")

            option = verify_int(option)
            option = verify_range(1,3,option,"integer")

            if option == 1:

                age = input("Ingrese la edad nueva edad del estudiante: ")
                age = verify_int(age)
                age = verify_positive(age,"integer")

                #Changing age of the student
                students[id]["age"] = age

                #Output
                print(SUCCESS + f"La edad del estudiante con id #{id} se ha cambiado a {age} exitosamente" + RESET)

            elif option == 2:


                grade = input("Ingrese la nueva nota del estudiante del 0 al 5: ")
                grade = verify_float(grade)
                grade = verify_range(0,5,grade,"float")

                #Changing grade of the student
                students[id]["grade"] = grade

            #Both options
            else:

                age = input("Ingrese la edad nueva edad del estudiante: ")
                age = verify_int(age)
                age = verify_positive(age,"integer")

                #Changing age of the student
                students[id]["age"] = age

                grade = input("Ingrese la nueva nota del estudiante del 0 al 5: ")
                grade = verify_float(grade)
                grade = verify_range(0,5,grade,"float")

                #Changing grade of the student
                students[id]["grade"] = grade

                #Output
                print(SUCCESS + f"La edad y la nota del estudiante con id #{id} se han cambiado exitosamente" + RESET)
    
    main()

def option_4_delete_student():
    """Function that deletes a student provided that there is at least one 
    student in the students' dictionary"""

    if verify_min_students(students):
        pass
    else:
        id = input("Ingrese el id del estudiante que desea eliminar: ")

        id = verify_int(id)
        id = verify_positive(id,"integer")

        if id not in students.keys():

            #Output
            print(WARNING + f"El estudiante con id #{id} no existe" + RESET)
        else:

            #Deleting student
            del students[id]

            #Output
            print(SUCCESS + f"Se ha eliminado al estudiante con id #{id} exitosamente" + RESET)
    
    main()

                 
def option_5_calculate_mean_grades():
    """Function that calculates the mean of grades provided that there is at least one 
    student in the students' dictionary"""

    if verify_min_students(students):
        pass
    else:

        number_students = len(students)
        sum_student_grades = 0

        for t in students.values():

            sum_student_grades += t["grade"]
        
        mean = sum_student_grades/number_students

        #Output
        print(SUCCESS + f"El promedio de notas es: {mean:.2f}" + RESET)

    main()

def option_6_list_students():
    """Function that lists students that are under a given umbral provided that there is at least one 
    student in the students' dictionary"""

    if verify_min_students(students):
        pass
    else:

        umbral = input("Ingrese el umbral del cual le gustaria saber los estudiantes con nota menor a: ")

        umbral = verify_float(umbral)
        umbral = verify_range(0,5,umbral,"float")

        #List that will store the indexes of the students that are under the umbral
        umbral_students_indexes = []

        for i in students.items():

            if i[1]["grade"] < umbral:
                umbral_students_indexes.append(i[0])
        
        if len(umbral_students_indexes) == 0:
            #Output
            print(WARNING + f"No hay estudiantes que tengan menos que {umbral} de nota" + RESET)
        else:

            #Output
            print(SUCCESS + "=====================" + RESET)
            for k in umbral_students_indexes:
                print("=====================")
                print(f"Id: {k}")
                print(f"Nombre: {students[k]["name"]}")
                print(f"Edad: {students[k]["age"]}")
                print(f"Nota: {students[k]["grade"]}")
                print("=====================")
            print(SUCCESS + "=====================" + RESET)
    
    main()



main()